Installing the swatches.


Illustrator

1. Download the palettes.2. Put the folder color_swatches > illustrator > Google here: Macintosh HD > Applications > Adobe Illustrator CSx > Presets > en_US > Swatches3. Load the swatch palettes in Illustrator. Window > Swatch Libraries > Google




Photoshop
1. Download the palettes.2. Put the files from the folder color_swatches > photoshop > here: Macintosh HD > Applications > Adobe Photoshop CSx > Presets > Color Swatches3. Open the swatch window. Window > Swatches. Click the drop down menu in the top right corner of the window. You’ll find the Material Palette and Material Expanded Palette in the list. Select OK to replace current swatches. 

